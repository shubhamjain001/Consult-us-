<!-- Planning and Implementation:

Create Patient route, Doctor route, and related doctor and patient models 

case 1:
once patient logs in:
he/she view all doctor basic info like name specialisation available time


then patient book doctor appointment, -> give remote video call option as well

patient able to see appointment info at their dashboard
able to cancel or reschedule appointment

case 2:
once doctor logs in:
he/she can see their appointments with patients



here1
open
here10
here2

here3
here7
here8 -->